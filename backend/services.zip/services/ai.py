"""
ai.py – OpenRouter integration for summarization, Q&A, and multilingual responses
"""
import os
import json
import time
import logging
from typing import Optional
from openai import OpenAI

logger = logging.getLogger(__name__)

# ── Language display names ────────────────────────────────────
LANGUAGE_NAMES = {
    "en": "English",
    "hi": "Hindi (हिन्दी)",
    "ta": "Tamil (தமிழ்)",
    "te": "Telugu (తెలుగు)",
    "kn": "Kannada (ಕನ್ನಡ)",
    "mr": "Marathi (मराठी)",
    "bn": "Bengali (বাংলা)",
    "gu": "Gujarati (ગુજરાતી)",
}

client = OpenAI(
    api_key=os.getenv("OPENROUTER_API_KEY"),
    base_url=os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"),
    default_headers={
        "HTTP-Referer": "https://youtube-summarizer-bot.app",
        "X-Title": "YouTube Summarizer Bot",
    },
)

# Default to Mistral 7B (stable, widely available)
# Override with OPENROUTER_MODEL env var for other models like:
#   - google/gemini-2.0-flash-exp
#   - meta-llama/llama-2-7b-chat
#   - openchat/openchat-3.5
MODEL = os.getenv("OPENROUTER_MODEL", "google/gemini-2.5-pro")


def _call(messages: list, max_tokens: int = 2000, temperature: float = 0.3) -> tuple[str, dict]:
    """Raw OpenRouter call. Returns (content, usage)."""
    t0 = time.time()
    try:
        resp = client.chat.completions.create(
            model=MODEL,
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
        )
        content = resp.choices[0].message.content or ""
        usage = {
            "prompt_tokens": resp.usage.prompt_tokens if resp.usage else 0,
            "completion_tokens": resp.usage.completion_tokens if resp.usage else 0,
            "latency_ms": round((time.time() - t0) * 1000),
        }
        return content, usage
    except Exception as e:
        error_str = str(e)
        if "404" in error_str:
            logger.error(f"OpenRouter model '{MODEL}' not found. Error: {e}\n"
                        f"Check available models on OpenRouter or set OPENROUTER_MODEL env var.")
        else:
            logger.error(f"OpenRouter call failed: {e}")
        raise


# ─────────────────────────────────────────────────────────────
# SUMMARIZATION
# ─────────────────────────────────────────────────────────────

SUMMARY_SYSTEM = """You are an expert AI research assistant specializing in YouTube video analysis.
Your task is to create structured, insightful summaries that save people time and extract real value.
Always respond with valid JSON only – no markdown fences, no extra text."""

SUMMARY_PROMPT = """Analyze this YouTube video transcript and produce a structured summary.

VIDEO TITLE: {title}
TRANSCRIPT:
{transcript}

Respond ONLY with this JSON structure:
{{
  "key_points": ["point 1", "point 2", "point 3", "point 4", "point 5"],
  "timestamps": [
    {{"time": "0:00", "label": "topic description"}},
    {{"time": "2:30", "label": "topic description"}},
    {{"time": "5:00", "label": "topic description"}}
  ],
  "core_insight": "One powerful sentence capturing the single most important takeaway.",
  "summary_paragraph": "2-3 sentence overview of the entire video.",
  "action_points": ["actionable item 1", "actionable item 2", "actionable item 3"],
  "target_audience": "Who benefits most from this video",
  "content_type": "tutorial|interview|lecture|review|news|other"
}}

Rules:
- Key points must be specific and factual, not generic
- Timestamps must match actual content in the transcript (estimate from text position if needed)
- Core insight must be genuinely insightful, not a restatement of the title
- Action points must be concrete and immediately useful"""


def generate_summary(transcript: str, title: str, language: str = "en") -> dict:
    """
    Generate a structured summary using hierarchical map-reduce.
    Full transcript is preserved — no truncation.
    """
    # ── UPGRADE: map-reduce replaces transcript[:24000] truncation ──
    from services.summarizer import hierarchical_summarize
    result = hierarchical_summarize(transcript, title, _call)
    # ────────────────────────────────────────────────────────────────

    # Translate if needed
    if language != "en":
        result = translate_summary(result, language)

    return result


# ─────────────────────────────────────────────────────────────
# Q&A
# ─────────────────────────────────────────────────────────────

QA_SYSTEM = """You are an AI assistant that answers questions strictly based on YouTube video transcripts.

RULES:
1. Only answer using information from the provided transcript
2. If the answer is not in the transcript, say exactly: "This topic is not covered in the video."
3. Be specific and cite what was said, not general knowledge
4. Keep answers concise but complete (2-4 sentences unless more detail is needed)
5. Never hallucinate or add information not in the transcript
6. If asked in a specific language, respond in that language"""

QA_PROMPT = """VIDEO TITLE: {title}

TRANSCRIPT CONTEXT:
{context}

CONVERSATION HISTORY:
{history}

USER QUESTION: {question}

Answer the question based only on the transcript above."""


def answer_question(
    question: str,
    transcript: str,
    title: str,
    history: list[dict],
    language: str = "en",
    video_id: str = "",          # ← NEW: pass video_id for FAISS index lookup
) -> tuple[str, dict]:
    """
    Answer a user question grounded in the transcript.
    Uses semantic FAISS retrieval + hallucination score guard.
    Returns (answer_text, usage).
    """
    # ── UPGRADE: semantic retrieval replaces keyword search ───────
    from services.retriever import retrieve_context, check_relevance, NOT_IN_VIDEO_MSG

    if video_id:
        context, best_score = retrieve_context(question, video_id, transcript)
        if not check_relevance(best_score):
            logger.info(f"Q&A rejected (score={best_score:.3f} < threshold): '{question[:60]}'")
            return NOT_IN_VIDEO_MSG, {"prompt_tokens": 0, "completion_tokens": 0, "latency_ms": 0}
    else:
        # Fallback to full transcript if no video_id supplied
        context = transcript[:12000]
    # ──────────────────────────────────────────────────────────────

    # Build history string (last 6 exchanges)
    recent = history[-12:] if len(history) > 12 else history
    history_str = "\n".join(
        f"{'User' if m['role'] == 'user' else 'Assistant'}: {m['content']}"
        for m in recent
    )

    lang_instruction = ""
    if language != "en":
        lang_name = LANGUAGE_NAMES.get(language, language)
        lang_instruction = f"\n\nIMPORTANT: Respond entirely in {lang_name}."

    messages = [
        {"role": "system", "content": QA_SYSTEM + lang_instruction},
        {"role": "user", "content": QA_PROMPT.format(
            title=title,
            context=context,
            history=history_str or "No previous conversation.",
            question=question,
        )},
    ]

    answer, usage = _call(messages, max_tokens=800, temperature=0.2)
    return answer.strip(), usage


# _find_relevant_context() removed — replaced by services/retriever.py:retrieve_context()


# ─────────────────────────────────────────────────────────────
# TRANSLATION / MULTILINGUAL
# ─────────────────────────────────────────────────────────────

def translate_summary(summary: dict, target_language: str) -> dict:
    """Translate summary fields to target language."""
    lang_name = LANGUAGE_NAMES.get(target_language, target_language)

    content_to_translate = {
        "key_points": summary.get("key_points", []),
        "core_insight": summary.get("core_insight", ""),
        "summary_paragraph": summary.get("summary_paragraph", ""),
        "action_points": summary.get("action_points", []),
    }

    messages = [
        {"role": "system", "content": f"You are a professional translator. Translate the following JSON content to {lang_name}. Preserve the JSON structure exactly. Respond with valid JSON only."},
        {"role": "user", "content": json.dumps(content_to_translate, ensure_ascii=False)},
    ]

    try:
        content, _ = _call(messages, max_tokens=1500)
        clean = content.strip().strip("```json").strip("```").strip()
        translated = json.loads(clean)
        summary.update(translated)
    except Exception as e:
        logger.error(f"Translation failed: {e}")

    return summary


def detect_language_request(text: str) -> Optional[str]:
    """
    Detect if user is requesting a specific language.
    Returns language code or None.
    """
    text_lower = text.lower()
    triggers = {
        "hindi": "hi", "हिंदी": "hi", "हिन्दी": "hi",
        "tamil": "ta", "தமிழ்": "ta",
        "telugu": "te", "తెలుగు": "te",
        "kannada": "kn", "ಕನ್ನಡ": "kn",
        "marathi": "mr", "मराठी": "mr",
        "bengali": "bn", "বাংলা": "bn",
        "gujarati": "gu", "ગુજરાતી": "gu",
        "english": "en",
    }
    for trigger, code in triggers.items():
        if trigger in text_lower:
            return code
    return None


def generate_deep_dive(transcript: str, title: str, language: str = "en") -> str:
    """Generate an extended deep-dive analysis."""
    truncated = transcript[:20000]
    messages = [
        {"role": "system", "content": "You are an expert content analyst. Provide deep, thoughtful analysis."},
        {"role": "user", "content": f"""Perform a deep-dive analysis of this video: {title}

TRANSCRIPT: {truncated}

Provide:
1. **Main Arguments** - Core thesis and supporting arguments
2. **Evidence & Examples** - Key examples or data mentioned  
3. **Implications** - What this means for the viewer
4. **Critical Perspective** - Any limitations or counterpoints
5. **Expert Verdict** - Your assessment of the content quality

{'Respond in ' + LANGUAGE_NAMES.get(language, language) + '.' if language != 'en' else ''}"""},
    ]
    content, _ = _call(messages, max_tokens=1200)
    return content


def generate_action_points(transcript: str, title: str, language: str = "en") -> str:
    """Extract concrete action points from the video."""
    truncated = transcript[:16000]
    messages = [
        {"role": "system", "content": "Extract concrete, actionable steps from video content."},
        {"role": "user", "content": f"""From this video "{title}", extract all actionable advice, steps, or recommendations.

TRANSCRIPT: {truncated}

Format as a numbered action plan with:
- Clear action items
- Why each matters
- How to implement

{'Respond in ' + LANGUAGE_NAMES.get(language, language) + '.' if language != 'en' else ''}"""},
    ]
    content, _ = _call(messages, max_tokens=1000)
    return content